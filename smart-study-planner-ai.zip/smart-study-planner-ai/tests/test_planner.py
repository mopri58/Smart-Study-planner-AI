import pandas as pd
from datetime import date
from planner import calculate_priority, generate_schedule


def sample_tasks():
    return pd.DataFrame([
        {"id": 1, "subject": "Maths", "topic": "Matrices", "due_date": "2026-10-20",
         "difficulty": "Hard", "estimated_hours": 2.0, "status": "Pending"},
        {"id": 2, "subject": "Python", "topic": "Functions", "due_date": "2026-10-30",
         "difficulty": "Easy", "estimated_hours": 1.0, "status": "Pending"},
    ])


def test_hard_urgent_task_has_higher_priority():
    tasks = sample_tasks()
    assert calculate_priority(tasks.iloc[0].to_dict(), date(2026, 10, 18)) > \
           calculate_priority(tasks.iloc[1].to_dict(), date(2026, 10, 18))


def test_daily_hours_limit_is_respected():
    plan = generate_schedule(sample_tasks(), date(2026, 10, 18), 3, 2)
    if not plan.empty:
        totals = plan.groupby("date")["hours"].sum()
        assert (totals <= 2.00001).all()


def test_completed_tasks_are_not_scheduled():
    tasks = sample_tasks()
    tasks.loc[:, "status"] = "Completed"
    plan = generate_schedule(tasks, date(2026, 10, 18), 3, 2)
    assert plan.empty


def test_empty_input_returns_empty_schedule():
    plan = generate_schedule(pd.DataFrame(), date(2026, 10, 18), 7, 3)
    assert plan.empty
